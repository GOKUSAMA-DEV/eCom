import A from "./Menu/A.jpg"

const MenuData = [
    {
        imgsrc: A,
        cardname: "Simple",
        desc: "It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout.",
    },
    {
        imgsrc: A,
        cardname: "Simple",
        desc: "It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout.",
    },
    {
        imgsrc: A,
        cardname: "Simple",
        desc: "It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout.",
    },
    {
        imgsrc: A,
        cardname: "Simple",
        desc: "It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout.",
    },
    {
        imgsrc: A,
        cardname: "Simple",
        desc: "It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout.",
    },
    {
        imgsrc: A,
        cardname: "Simple",
        desc: "It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout.",
    },
    {
        imgsrc: A,
        cardname: "Simple",
        desc: "It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout.",
    },
    {
        imgsrc: A,
        cardname: "Simple",
        desc: "It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout.",
    },
    {
        imgsrc: A,
        cardname: "Simple",
        desc: "It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout.",
    },
    {
        imgsrc: A,
        cardname: "Simple",
        desc: "It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout.",
    },
    {
        imgsrc: A,
        cardname: "Simple",
        desc: "It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout.",
    },
    {
        imgsrc: A,
        cardname: "Simple",
        desc: "It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout.",
    },
    
]

export default MenuData;